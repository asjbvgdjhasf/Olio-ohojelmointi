#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QFont>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    timer = new QTimer(this);
    connect(timer, &QTimer::timeout, this, &MainWindow::timeout);

    player1Time = 0;
    player2Time = 0;
    currentPlayer = 0;
    gameTime = 0;

    ui->player1ProgressBar->setRange(0, 100);
    ui->player2ProgressBar->setRange(0, 100);
    ui->player1ProgressBar->setValue(0);
    ui->player2ProgressBar->setValue(0);

    setGameInfoText("Select playtime and press start game!", 12);

    ui->switchPlayer1Button->setEnabled(false);
    ui->switchPlayer2Button->setEnabled(false);
    ui->startGameButton->setEnabled(false);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::timeout()
{
    if (currentPlayer == 1) {
        player1Time--;
        if (player1Time <= 0) {
            player1Time = 0;
            timer->stop();
            setGameInfoText("Player 1 WON!!", 20);
            ui->switchPlayer1Button->setEnabled(false);
            ui->switchPlayer2Button->setEnabled(false);
        }
    } else if (currentPlayer == 2) {
        player2Time--;
        if (player2Time <= 0) {
            player2Time = 0;
            timer->stop();
            setGameInfoText("Player 2 WON!!", 20);
            ui->switchPlayer1Button->setEnabled(false);
            ui->switchPlayer2Button->setEnabled(false);
        }
    }

    updateProgressBars();
}

void MainWindow::updateProgressBars()
{
    if (gameTime > 0) {
        int player1Progress = (player1Time * 100) / gameTime;
        int player2Progress = (player2Time * 100) / gameTime;

        ui->player1ProgressBar->setValue(player1Progress);
        ui->player2ProgressBar->setValue(player2Progress);
    }
}

void MainWindow::setGameInfoText(QString text, short fontSize)
{
    QFont font = ui->infoLabel->font();
    font.setPointSize(fontSize);
    ui->infoLabel->setFont(font);
    ui->infoLabel->setText(text);
}

void MainWindow::on_switchPlayer1Button_clicked()
{
    currentPlayer = 2;
    ui->switchPlayer1Button->setEnabled(false);
    ui->switchPlayer2Button->setEnabled(true);
    setGameInfoText("Game ongoing", 14);
}

void MainWindow::on_switchPlayer2Button_clicked()
{
    currentPlayer = 1;
    ui->switchPlayer1Button->setEnabled(true);
    ui->switchPlayer2Button->setEnabled(false);
    setGameInfoText("Game ongoing", 14);
}

void MainWindow::on_startGameButton_clicked()
{
    if (gameTime > 0) {
        player1Time = gameTime;
        player2Time = gameTime;
        currentPlayer = 1;

        ui->switchPlayer1Button->setEnabled(true);
        ui->switchPlayer2Button->setEnabled(false);
        ui->playTime120SecButton->setEnabled(false);
        ui->playTime5MinButton->setEnabled(false);

        updateProgressBars();
        setGameInfoText("Game ongoing", 14);

        timer->start(1000);
    }
}

void MainWindow::on_stopGameButton_clicked()
{
    timer->stop();

    player1Time = 0;
    player2Time = 0;
    currentPlayer = 0;
    gameTime = 0;

    ui->player1ProgressBar->setValue(0);
    ui->player2ProgressBar->setValue(0);

    ui->switchPlayer1Button->setEnabled(false);
    ui->switchPlayer2Button->setEnabled(false);
    ui->playTime120SecButton->setEnabled(true);
    ui->playTime5MinButton->setEnabled(true);
    ui->startGameButton->setEnabled(false);

    setGameInfoText("Select playtime and press start game!", 12);
}

void MainWindow::on_playTime120SecButton_clicked()
{
    gameTime = TIME_120_SEC;
    player1Time = gameTime;
    player2Time = gameTime;

    updateProgressBars();
    setGameInfoText("Ready to play", 14);

    ui->startGameButton->setEnabled(true);
    ui->playTime120SecButton->setEnabled(false);
    ui->playTime5MinButton->setEnabled(false);
}

void MainWindow::on_playTime5MinButton_clicked()
{
    gameTime = TIME_5_MIN;
    player1Time = gameTime;
    player2Time = gameTime;

    updateProgressBars();
    setGameInfoText("Ready to play", 14);

    ui->startGameButton->setEnabled(true);
    ui->playTime120SecButton->setEnabled(false);
    ui->playTime5MinButton->setEnabled(false);
}
