#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTimer>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    void updateProgressBars();
    void setGameInfoText(QString text, short fontSize);

public slots:
    void timeout();

private slots:
    void on_switchPlayer1Button_clicked();
    void on_switchPlayer2Button_clicked();
    void on_startGameButton_clicked();
    void on_stopGameButton_clicked();
    void on_playTime120SecButton_clicked();
    void on_playTime5MinButton_clicked();

private:
    Ui::MainWindow *ui;
    QTimer *timer;

    int player1Time;
    int player2Time;
    int currentPlayer;
    int gameTime;
    const int TIME_120_SEC = 120;
    const int TIME_5_MIN = 300;
};
#endif
