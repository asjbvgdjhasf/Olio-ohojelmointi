#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDebug>
#include <QPushButton>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    QList<QPushButton*> numberButtons = {
        ui->N0, ui->N1, ui->N2, ui->N3, ui->N4,
        ui->N5, ui->N6, ui->N7, ui->N8, ui->N9
    };

    for (QPushButton* button : numberButtons) {
        connect(button, &QPushButton::clicked, this, &MainWindow::numberClickHandler);
    }

    number1 = "";
    number2 = "";
    state = 1;
    ui->num1->setText("");
    ui->num2->setText("");
    ui->result->setText("");
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::numberClickHandler()
{
    QPushButton* button = qobject_cast<QPushButton*>(sender());
    if (!button) return;

    QString digit = button->text();

    if (state == 1) {
        number1 += digit;
        ui->num1->setText(number1);
        qDebug() << "Number1:" << number1 << "Number2:" << number2;
    } else if (state == 2) {
        number2 += digit;
        ui->num2->setText(number2);
        qDebug() << "Number1:" << number1 << "Number2:" << number2;
    }
}

void MainWindow::on_add_clicked()
{
    operand = 0;
    state = 2;
    qDebug() << "Operation: ADD";
}

void MainWindow::on_sub_clicked()
{
    operand = 1;
    state = 2;
    qDebug() << "Operation: SUBTRACT";
}

void MainWindow::on_mul_clicked()
{
    operand = 2;
    state = 2;
    qDebug() << "Operation: MULTIPLY";
}

void MainWindow::on_div_clicked()
{
    operand = 3;
    state = 2;
    qDebug() << "Operation: DIVIDE";
}

void MainWindow::on_clear_clicked()
{
    state = 1;
    number1 = "";
    number2 = "";
    ui->num1->setText("");
    ui->num2->setText("");
    ui->result->setText("");
    qDebug() << "Cleared all fields";
}

void MainWindow::on_enter_clicked()
{
    if (number1.isEmpty() || number2.isEmpty()) {
        qDebug() << "Please enter both numbers";
        return;
    }

    float num1 = number1.toFloat();
    float num2 = number2.toFloat();

    switch (operand) {
    case 0: // add
        result = num1 + num2;
        break;
    case 1: // subtract
        result = num1 - num2;
        break;
    case 2: // multiply
        result = num1 * num2;
        break;
    case 3: // divide
        if (num2 != 0) {
            result = num1 / num2;
        } else {
            qDebug() << "Error: Division by zero";
            ui->result->setText("Error");
            return;
        }
        break;
    default:
        qDebug() << "No operation selected";
        return;
    }

    ui->result->setText(QString::number(result));
    qDebug() << "Result:" << result;

    // Reset
    state = 1;
    number1 = "";
    number2 = "";
}
